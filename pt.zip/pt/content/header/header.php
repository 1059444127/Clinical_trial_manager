<?php
/**
* Header file for all pages
*/
if ( !defined('ABSPATH') )
	exit();
?>
<?php 

echo get_sidebar_menu();
echo get_top_nav();

?>