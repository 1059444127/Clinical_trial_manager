<?php 
// if accessed directly than exit
if (!defined('ABSPATH')) exit; 
?>

<!-- jQuery -->
<script src="<?php echo JS_URL;?>jquery.min.js"></script>
<!-- jQuery -->
<script src="<?php echo JS_URL;?>jquery-ui.js"></script>
<!-- canvas dot -->
<script src="<?php echo JS_URL;?>canvasdots.js"></script>
<!-- Bootstrap -->
<script src="<?php echo JS_URL;?>bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo JS_URL;?>fastclick.js"></script>
<!-- NProgress -->
<script src="<?php echo JS_URL;?>nprogress.js"></script>
 <!-- morris.js -->
<script src="<?php echo JS_URL;?>raphael.min.js"></script>
<script src="<?php echo JS_URL;?>morris.min.js"></script>
<!-- Chart.js -->
<script src="<?php echo JS_URL;?>Chart.min.js"></script>
<!-- gauge.js -->
<script src="<?php echo JS_URL;?>gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="<?php echo JS_URL;?>bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="<?php echo JS_URL;?>icheck.min.js"></script>
<!-- Skycons -->
<script src="<?php echo JS_URL;?>skycons.js"></script>
<!-- Flot -->
<script src="<?php echo JS_URL;?>jquery.flot.js"></script>
<script src="<?php echo JS_URL;?>jquery.flot.pie.js"></script>
<script src="<?php echo JS_URL;?>jquery.flot.time.js"></script>
<script src="<?php echo JS_URL;?>jquery.flot.stack.js"></script>
<script src="<?php echo JS_URL;?>jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="<?php echo JS_URL;?>jquery.flot.orderBars.js"></script>
<script src="<?php echo JS_URL;?>date.js"></script>
<script src="<?php echo JS_URL;?>jquery.flot.spline.js"></script>
<script src="<?php echo JS_URL;?>curvedLines.js"></script>
<!-- jVectorMap -->
<script src="<?php echo JS_URL;?>jquery-jvectormap-2.0.3.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo JS_URL;?>moment.min.js"></script>
<script src="<?php echo JS_URL;?>fullcalendar.min.js"></script>
<script src="<?php echo JS_URL;?>daterangepicker.js"></script>
<!-- datatables -->
 <script src="<?php echo JS_URL;?>jquery.dataTables.min.js"></script>
<script src="<?php echo JS_URL;?>dataTables.bootstrap.min.js"></script>
<script src="<?php echo JS_URL;?>dataTables.buttons.min.js"></script>
<script src="<?php echo JS_URL;?>buttons.bootstrap.min.js"></script>
<script src="<?php echo JS_URL;?>buttons.flash.min.js"></script>
<script src="<?php echo JS_URL;?>buttons.html5.min.js"></script>
<script src="<?php echo JS_URL;?>buttons.print.min.js"></script>
<script src="<?php echo JS_URL;?>dataTables.fixedHeader.min.js"></script>
<script src="<?php echo JS_URL;?>dataTables.keyTable.min.js"></script>
<script src="<?php echo JS_URL;?>dataTables.responsive.min.js"></script>
<script src="<?php echo JS_URL;?>responsive.bootstrap.js"></script>
<script src="<?php echo JS_URL;?>datatables.scroller.min.js"></script>
<script src="<?php echo JS_URL;?>jszip.min.js"></script>
<script src="<?php echo JS_URL;?>pdfmake.min.js"></script>
<script src="<?php echo JS_URL;?>vfs_fonts.js"></script>
 <script src="<?php echo JS_URL;?>bootstrap-wysiwyg.min.js"></script>
<script src="<?php echo JS_URL;?>jquery.hotkeys.js"></script>
<script src="<?php echo JS_URL;?>prettify.js"></script>
<!-- jQuery Tags Input -->
<script src="<?php echo JS_URL;?>jquery.tagsinput.js"></script>
<!-- Switchery -->
<script src="<?php echo JS_URL;?>switchery.min.js"></script>
<!-- Select2 -->
<script src="<?php echo JS_URL;?>select2.full.min.js"></script>
<!-- Parsley -->
<script src="<?php echo JS_URL;?>parsley.min.js"></script>
<!-- Autosize -->
<script src="<?php echo JS_URL;?>autosize.min.js"></script>
<!-- jQuery autocomplete -->
<script src="<?php echo JS_URL;?>jquery.autocomplete.min.js"></script>
<!-- starrr -->
<script src="<?php echo JS_URL;?>starrr.js"></script>
<!-- p notify -->
<script src="<?php echo JS_URL;?>pnotify.js"></script>
<script src="<?php echo JS_URL;?>pnotify.buttons.js"></script>
<script src="<?php echo JS_URL;?>pnotify.nonblock.js"></script>