<?php 
// if accessed directly than exit
if (!defined('ABSPATH')) exit;
?>

<!-- Custom Theme Scripts -->
<script src="<?php echo JS_URL;?>custom.js"></script>
<script src="<?php echo JS_URL;?>styles.js"></script>