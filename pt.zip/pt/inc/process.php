<?php
session_start();
//Load all functions
require_once('../load.php');
require_once( ABSPATH . CONTENT . '/process/process.php');
?>