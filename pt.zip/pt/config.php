<?php
define('DB_NAME', 'randomise');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define( 'INC', 'inc' );
define( 'CONTENT', 'content' );
define('WEBPATH','pt');

if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
	
?>